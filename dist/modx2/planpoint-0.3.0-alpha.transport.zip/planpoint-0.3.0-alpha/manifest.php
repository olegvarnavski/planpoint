<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '# PlanPoint

**Визуальный редактор интерактивных планировок для MODX Revolution 2.8.**

Загрузите изображение этажа, обведите помещения, задайте ключи квартир и назначьте готовую схему одному или нескольким этажам. PlanPoint хранит схемы отдельно от квартир и выводит изображение с SVG для существующего интерфейса сайта.

Текущая версия: **0.3.0-alpha**. Это рабочая альфа с ограниченным набором SVG-конструкций.

[Пакет MODX 2.8](dist/modx2/planpoint-0.3.0-alpha.transport.zip) · [Экспериментальный пакет MODX 3.2](dist/modx3/planpoint-0.3.0-alpha.transport.zip) · [Установка](docs/INSTALLATION.md) · [Редактор](docs/EDITOR.md) · [Подключение к сайту](docs/INTEGRATION.md) · [Разработка](docs/DEVELOPMENT.md) · [Изменения](docs/CHANGELOG.md)

## Возможности

- Вкладка «Планировки» у настроенных ресурсов домов и этажей.
- Несколько схем для одного дома, назначение этажам и выбор диапазонов.
- Подложки PNG/JPG; интеграция с установленным mixedImage через настройки TV, по умолчанию `imgMigx`.
- Непрерывная обводка: линия до курсора, полупрозрачная область, замыкание по первой точке, следующий номер автоматически.
- Горизонтальные и вертикальные стороны по Shift или в постоянном режиме прямых углов.
- Перемещение вершин и SVG-точек, добавление и удаление вершин, история отмены/повтора.
- Вертикальная панель инструментов, свойства выбранного контура, подробная справка под редактором.
- Прямое редактирование номера и `data-i`; секция задаётся у общей схемы.
- Импорт SVG, просмотр и редактирование кода в локальном Ace, копирование и скачивание SVG/HTML.
- Просмотр, редактирование, назначение этажей, копирование и удаление через действия строки и контекстное меню.
- Защита от перезаписи устаревшей ревизией и конфликтов назначения этажей.
- Сниппет `PlanPointRender`, включая вывод без дополнительных чанков для файлового Fenom-шаблона.

## Требования

MODX Revolution **2.8.x**, PHP **7.4+**; экспериментально MODX **3.2.x**, PHP **8.1+**, MySQL с InnoDB, расширения DOM, mbstring и PDO MySQL. Для менеджера — современный браузер на ПК. Облачные Media Source не поддерживаются. Границы адаптации MODX 3 описаны в [MODX3.md](docs/MODX3.md).

Тестовые версии ядра — **2.8.5-pl** и **3.2.2-pl**. Локальные проверки выполнены на PHP 8.3 и MariaDB 10.11 через PDO MySQL. Это не заменяет проверку конкретной версии MySQL/PHP и дополнений рабочего сайта. [Подробности проверки](docs/VALIDATION.md).

## Быстрая установка

1. Скачайте именно файл `planpoint-0.3.0-alpha.transport.zip` из `dist/modx2` либо `dist/modx3` под вашу платформу, а не архив исходников GitHub.
2. Загрузите его в `core/packages/` и установите через менеджер пакетов MODX.
3. В пространстве настроек `planpoint` задайте ID шаблонов домов, подъездов и этажей.
4. Откройте сохранённый ресурс дома, добавьте схему, обведите помещения и назначьте этажи.
5. Подключите вывод в шаблоне сайта отдельно.

Обновление пакета с техническим именем `planpoint` сохраняет схемы и назначения. Предыдущий пакет с именем `planeditor` — отдельная установка: автоматического переноса из него нет, старый плагин `PlanEditorManager` следует отключить.

## Файловые чанки и Fenom

В существующем файловом чанке `chunks/catalog/plan/svg.tpl`:

```smarty
{set $scheme = $_modx->runSnippet(\'PlanPointRender\', [
    \'floorId\' => $_modx->resource.id,
    \'inner\' => 1
])}
```

`$scheme` содержит только `<picture>` и `<svg>`. Если схема не назначена, возвращается пустая строка. Внешняя `.plan-svg`, улицы и вывод пинов квартир остаются в текущем файловом шаблоне. Дополнительные чанки создавать не требуется.

[Готовый пример svg.tpl](examples/chunks/catalog/plan/svg.tpl) сохраняет существующий вывод `msProducts` с шаблоном квартир 4. Это пример под конкретную структуру ресурсов; проверьте свои ID шаблонов и наследование улиц.

Ключи должны совпадать буквально: контур `data-i="x2-03"`, SVG-точка `data-pin="x2-03"`, HTML-пин и карточка квартиры с таким же ключом. Начальные нули сохраняются. PlanPoint не создаёт квартиры и не заменяет mFilter2.

## Ограничения

Поддерживаются замкнутые прямолинейные SVG-пути M/L/H/V/Z, включая относительные команды, и точки `circle[data-pin]`. Кривые, группы, transform, составные пути и активный код отклоняются. Сложные SVG не упрощаются автоматически.

История отмены хранится в открытом редакторе до сохранения или импорта. Автосохранения нет. При замене изображения координаты контуров сохраняются, viewBox и пропорции обновляются по новому файлу; положение контуров нужно проверить.

Пользователь с правом просмотра дома может работать со схемами; права файлового источника проверяются отдельно. Отдельного ограничения удаления схем только администратором пока нет. [Статус разработки](docs/STATUS.md).

## Структура

| Каталог | Содержимое |
| --- | --- |
| `core/components/planpoint` | PHP-сервис, схема БД, процессор, сниппет и плагин |
| `assets/components/planpoint` | Редактор, стили, коннектор и локальный Ace |
| `_build` | Сборка и обработчики установки |
| `dist` | Готовый транспортный пакет MODX |
| `examples` | Пример подключения в файловом чанке |
| `tests` | PHP, геометрия и браузерные проверки |
| `docs` | Руководства, ТЗ, ограничения и история |

Сторонний редактор Ace поставляется со своей [лицензией](assets/components/planpoint/vendor/ace/LICENSE). Отдельная открытая лицензия для кода PlanPoint пока не выбрана.

## 0.3.0: надёжность и MODX 3

[Исправления по аудиту](docs/RELIABILITY.md): согласованная история изображения/viewBox, стабильный источник файла, проверяемая установка, идемпотентное создание/копирование, облегчённый список, типизированный ввод API и диагностика. Бизнес-логика схем, назначений, квартир и файловой интеграции сохранена. [MODX 3](docs/MODX3.md) пока имеет экспериментальный статус.
',
    'license' => 'Copyright 2026. Created for the project owner.',
    'requires' => 
    array (
      'php' => '>=7.4',
      'modx' => '>=2.8.0 <2.9.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'fce0d73073294ebf5eedc686edd6bdde',
      'native_key' => 'planpoint',
      'filename' => 'modNamespace/07c05165f61425c737e0c0a1fbd73bda.vehicle',
      'namespace' => 'planpoint',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6cdb7f3dc52b2d1c59ee4af0f15f31f0',
      'native_key' => 'planpoint.house_templates',
      'filename' => 'modSystemSetting/a2c790162a4102b6452d5046b1100c2a.vehicle',
      'namespace' => 'planpoint',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87eef95d86fe93f96c6ec2189fc8e99d',
      'native_key' => 'planpoint.section_templates',
      'filename' => 'modSystemSetting/92be278713962d1312b55c2a8dc43d16.vehicle',
      'namespace' => 'planpoint',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd2d2430e9b159208117f43adf6782ee',
      'native_key' => 'planpoint.floor_templates',
      'filename' => 'modSystemSetting/a58b87bd3cc97158fc069b2892aaa77a.vehicle',
      'namespace' => 'planpoint',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '733347ca502e72891fd7f0c55c6f7e00',
      'native_key' => 'planpoint.media_source',
      'filename' => 'modSystemSetting/f877472b913bf13790024ebd9c587dbb.vehicle',
      'namespace' => 'planpoint',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c5164a3f9cc0bd397b3cf30901a96f9',
      'native_key' => 'planpoint.image_tv',
      'filename' => 'modSystemSetting/05fac3f0bb97339b0c1ce23e6d1acc06.vehicle',
      'namespace' => 'planpoint',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e4e32dde162f1e5090f4e3895022f4d',
      'native_key' => 'planpoint.image_folder',
      'filename' => 'modSystemSetting/3bef2f6d788ff0902824c3a7143e33ff.vehicle',
      'namespace' => 'planpoint',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '101339beaf8a512cf7a6013c74be7e57',
      'native_key' => 'planpoint.floor_number_field',
      'filename' => 'modSystemSetting/f7c0894c08f2c6ae6a1eb283329cbbbf.vehicle',
      'namespace' => 'planpoint',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c29ce825bbdfecc8ff204fab53483da7',
      'native_key' => 'planpoint.modx3_mixedimage',
      'filename' => 'modSystemSetting/3518df349a898899def8e7f4c4c7e529.vehicle',
      'namespace' => 'planpoint',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a82c8078dc8e584fe8e96324cd709e46',
      'native_key' => NULL,
      'filename' => 'modCategory/7ebf60c0372a208077b66e28b078a24f.vehicle',
      'namespace' => 'planpoint',
    ),
  ),
);