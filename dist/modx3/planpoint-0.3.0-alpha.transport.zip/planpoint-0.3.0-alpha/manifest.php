<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '# PlanPoint

**Визуальный редактор интерактивных планировок для MODX Revolution 2.8.**

Загрузите изображение этажа, обведите помещения, задайте ключи квартир и назначьте готовую схему одному или нескольким этажам. PlanPoint хранит схемы отдельно от квартир и выводит изображение с SVG для существующего интерфейса сайта.

Текущая версия: **0.3.0-alpha**. Это рабочая альфа с ограниченным набором SVG-конструкций.

[Пакет MODX 2.8](dist/modx2/planpoint-0.3.0-alpha.transport.zip) · [Экспериментальный пакет MODX 3.2](dist/modx3/planpoint-0.3.0-alpha.transport.zip) · [Установка](docs/INSTALLATION.md) · [Редактор](docs/EDITOR.md) · [Подключение к сайту](docs/INTEGRATION.md) · [Разработка](docs/DEVELOPMENT.md) · [Изменения](docs/CHANGELOG.md)

## Возможности

- Вкладка «Планировки» у настроенных ресурсов домов и этажей.
- Несколько схем для одного дома, назначение этажам и выбор диапазонов.
- Подложки PNG/JPG; интеграция с установленным mixedImage через настройки TV, по умолчанию `imgMigx`.
- Непрерывная обводка: линия до курсора, полупрозрачная область, замыкание по первой точке, следующий номер автоматически.
- Горизонтальные и вертикальные стороны по Shift или в постоянном режиме прямых углов.
- Перемещение вершин и SVG-точек, добавление и удаление вершин, история отмены/повтора.
- Вертикальная панель инструментов, свойства выбранного контура, подробная справка под редактором.
- Прямое редактирование номера и `data-i`; секция задаётся у общей схемы.
- Импорт SVG, просмотр и редактирование кода в локальном Ace, копирование и скачивание SVG/HTML.
- Просмотр, редактирование, назначение этажей, копирование и удаление через действия строки и контекстное меню.
- Защита от перезаписи устаревшей ревизией и конфликтов назначения этажей.
- Сниппет `PlanPointRender`, включая вывод без дополнительных чанков для файлового Fenom-шаблона.

## Требования

MODX Revolution **2.8.x**, PHP **7.4+**; экспериментально MODX **3.2.x**, PHP **8.1+**, MySQL с InnoDB, расширения DOM, mbstring и PDO MySQL. Для менеджера — современный браузер на ПК. Облачные Media Source не поддерживаются. Границы адаптации MODX 3 описаны в [MODX3.md](docs/MODX3.md).

Тестовые версии ядра — **2.8.5-pl** и **3.2.2-pl**. Локальные проверки выполнены на PHP 8.3 и MariaDB 10.11 через PDO MySQL. Это не заменяет проверку конкретной версии MySQL/PHP и дополнений рабочего сайта. [Подробности проверки](docs/VALIDATION.md).

## Быстрая установка

1. Скачайте именно файл `planpoint-0.3.0-alpha.transport.zip` из `dist/modx2` либо `dist/modx3` под вашу платформу, а не архив исходников GitHub.
2. Загрузите его в `core/packages/` и установите через менеджер пакетов MODX.
3. В пространстве настроек `planpoint` задайте ID шаблонов домов, подъездов и этажей.
4. Откройте сохранённый ресурс дома, добавьте схему, обведите помещения и назначьте этажи.
5. Подключите вывод в шаблоне сайта отдельно.

Обновление пакета с техническим именем `planpoint` сохраняет схемы и назначения. Предыдущий пакет с именем `planeditor` — отдельная установка: автоматического переноса из него нет, старый плагин `PlanEditorManager` следует отключить.

## Файловые чанки и Fenom

В существующем файловом чанке `chunks/catalog/plan/svg.tpl`:

```smarty
{set $scheme = $_modx->runSnippet(\'PlanPointRender\', [
    \'floorId\' => $_modx->resource.id,
    \'inner\' => 1
])}
```

`$scheme` содержит только `<picture>` и `<svg>`. Если схема не назначена, возвращается пустая строка. Внешняя `.plan-svg`, улицы и вывод пинов квартир остаются в текущем файловом шаблоне. Дополнительные чанки создавать не требуется.

[Готовый пример svg.tpl](examples/chunks/catalog/plan/svg.tpl) сохраняет существующий вывод `msProducts` с шаблоном квартир 4. Это пример под конкретную структуру ресурсов; проверьте свои ID шаблонов и наследование улиц.

Ключи должны совпадать буквально: контур `data-i="x2-03"`, SVG-точка `data-pin="x2-03"`, HTML-пин и карточка квартиры с таким же ключом. Начальные нули сохраняются. PlanPoint не создаёт квартиры и не заменяет mFilter2.

## Ограничения

Поддерживаются замкнутые прямолинейные SVG-пути M/L/H/V/Z, включая относительные команды, и точки `circle[data-pin]`. Кривые, группы, transform, составные пути и активный код отклоняются. Сложные SVG не упрощаются автоматически.

История отмены хранится в открытом редакторе до сохранения или импорта. Автосохранения нет. При замене изображения координаты контуров сохраняются, viewBox и пропорции обновляются по новому файлу; положение контуров нужно проверить.

Пользователь с правом просмотра дома может работать со схемами; права файлового источника проверяются отдельно. Отдельного ограничения удаления схем только администратором пока нет. [Статус разработки](docs/STATUS.md).

## Структура

| Каталог | Содержимое |
| --- | --- |
| `core/components/planpoint` | PHP-сервис, схема БД, процессор, сниппет и плагин |
| `assets/components/planpoint` | Редактор, стили, коннектор и локальный Ace |
| `_build` | Сборка и обработчики установки |
| `dist` | Готовый транспортный пакет MODX |
| `examples` | Пример подключения в файловом чанке |
| `tests` | PHP, геометрия и браузерные проверки |
| `docs` | Руководства, ТЗ, ограничения и история |

Сторонний редактор Ace поставляется со своей [лицензией](assets/components/planpoint/vendor/ace/LICENSE). Отдельная открытая лицензия для кода PlanPoint пока не выбрана.

## 0.3.0: надёжность и MODX 3

[Исправления по аудиту](docs/RELIABILITY.md): согласованная история изображения/viewBox, стабильный источник файла, проверяемая установка, идемпотентное создание/копирование, облегчённый список, типизированный ввод API и диагностика. Бизнес-логика схем, назначений, квартир и файловой интеграции сохранена. [MODX 3](docs/MODX3.md) пока имеет экспериментальный статус.
',
    'license' => 'Copyright 2026. Created for the project owner.',
    'requires' => 
    array (
      'php' => '>=8.1',
      'modx' => '>=3.2.0 <3.3.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '05aaac6a00a55a4a8cb8364377e04ff5',
      'native_key' => 'planpoint',
      'filename' => 'MODX/Revolution/modNamespace/23b28d630f87fbc572a3a00fcf6c0aee.vehicle',
      'namespace' => 'planpoint',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a88e30d50d24ec001960f23e487147a4',
      'native_key' => 'planpoint.house_templates',
      'filename' => 'MODX/Revolution/modSystemSetting/a6bd7aaf1f62fbd06ff018da223f4635.vehicle',
      'namespace' => 'planpoint',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9723cccdd43940cde5ac8f665cd8b3ca',
      'native_key' => 'planpoint.section_templates',
      'filename' => 'MODX/Revolution/modSystemSetting/34ef8624ac1900f22ab9f59de9797c67.vehicle',
      'namespace' => 'planpoint',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '64d9114958c82b4d903ac1965f9d8a83',
      'native_key' => 'planpoint.floor_templates',
      'filename' => 'MODX/Revolution/modSystemSetting/8264b69c48c27b6fd85c0e4e02e45bce.vehicle',
      'namespace' => 'planpoint',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e1fd224b554333b249a03925bb49933c',
      'native_key' => 'planpoint.media_source',
      'filename' => 'MODX/Revolution/modSystemSetting/507344e4e87091732f745b9862b0107c.vehicle',
      'namespace' => 'planpoint',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6924aad0db34adabef8a321b2ece635f',
      'native_key' => 'planpoint.image_tv',
      'filename' => 'MODX/Revolution/modSystemSetting/9da4d2a30d5f95b093fa9ab944a9111d.vehicle',
      'namespace' => 'planpoint',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0068d2422eed48b2ea70b096cdd691f4',
      'native_key' => 'planpoint.image_folder',
      'filename' => 'MODX/Revolution/modSystemSetting/7eb3061ff95e00f0c0a5aeb680c7b085.vehicle',
      'namespace' => 'planpoint',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0f51d58eabf1e3677c0dd4a357a2e684',
      'native_key' => 'planpoint.floor_number_field',
      'filename' => 'MODX/Revolution/modSystemSetting/fca88e2cdb23bacba68206f0a981e18b.vehicle',
      'namespace' => 'planpoint',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '963b5861e5e0bc9b27bd17ac83126285',
      'native_key' => 'planpoint.modx3_mixedimage',
      'filename' => 'MODX/Revolution/modSystemSetting/9d31bd3a205b21805366ce0dc3546454.vehicle',
      'namespace' => 'planpoint',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '1fd42564ad73a61fcc05706bef49748c',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/6f952ef5fbc4fa81da22620b26b97d55.vehicle',
      'namespace' => 'planpoint',
    ),
  ),
);